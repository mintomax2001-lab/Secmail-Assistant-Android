package com.mintomax.secmailprobe;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * Secmail Assistant v0.8 Lite
 *
 * Product goal:
 *   Open one mail in Secmail -> capture it locally via Accessibility
 *   -> explicitly share that one mail to ChatGPT -> get a recommended reply.
 *
 * Batch Inbox collection, Action Inbox, GPT batch import and automatic traversal are
 * intentionally not exposed in this Lite UI. The existing service/database classes are
 * retained for compatibility and rollback, but v0.8 Lite does not start batch collection.
 */
public class MainActivity extends Activity {
    private SharedPreferences prefs;

    private TextView serviceStatus;
    private TextView targetStatus;
    private TextView subjectView;
    private TextView metaView;
    private TextView toView;
    private TextView bodyView;
    private TextView debugView;

    private MailSnapshot currentMail;
    private boolean bodyExpanded = false;
    private boolean debugExpanded = false;

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(Color.rgb(20, 29, 43));
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, dp(2), 0, dp(5));
        return v;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        if (primary) {
            b.setBackgroundColor(Color.rgb(37, 99, 235));
            b.setTextColor(Color.WHITE);
        }
        return b;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        l.setLayoutParams(lp);
        return l;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.rgb(229, 234, 242));
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return v;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(ProbeAccessibilityService.PREFS, Context.MODE_PRIVATE);
        if (prefs.getString(ProbeAccessibilityService.KEY_TARGET, "").trim().isEmpty()) {
            prefs.edit()
                    .putString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET)
                    .apply();
        }

        // v0.8 Lite never performs Inbox batch traversal.
        // If an earlier version was interrupted while batch collection was active,
        // clear that state so no old overlay/automation resumes unexpectedly.
        prefs.edit()
                .putBoolean(ProbeAccessibilityService.KEY_BATCH_ACTIVE, false)
                .putString(ProbeAccessibilityService.KEY_BATCH_STATUS, "v0.8 Lite · 단건 메일 모드")
                .apply();

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(244, 247, 252));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(36));
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(dp(4), dp(4), dp(4), dp(12));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        header.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(58)));

        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(text("Secmail Reply Assistant", 23, true));
        TextView vs = text("v0.8 Lite · 현재 열린 메일 → GPT 추천답안", 12, false);
        vs.setTextColor(Color.rgb(99, 110, 128));
        ht.addView(vs);
        header.addView(ht, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(header);

        LinearLayout status = card();
        status.addView(text("1. 연결 확인", 16, true));
        serviceStatus = text("", 13, true);
        targetStatus = text("", 12, false);
        status.addView(serviceStatus);
        status.addView(targetStatus);

        TextView statusHelp = text(
                "Accessibility가 ON이어야 Secmail에서 직접 연 메일의 화면 내용을 읽을 수 있습니다.", 11, false);
        statusHelp.setTextColor(Color.rgb(99, 110, 128));
        status.addView(statusHelp);

        LinearLayout statusBtns = new LinearLayout(this);
        Button access = button("접근성 설정", false);
        Button openSecmail = button("Secmail 열기", true);
        statusBtns.addView(access, new LinearLayout.LayoutParams(0, dp(50), 1f));
        statusBtns.addView(openSecmail, new LinearLayout.LayoutParams(0, dp(50), 1f));
        status.addView(statusBtns);

        access.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        openSecmail.setOnClickListener(v -> openSecmail());
        root.addView(status);

        LinearLayout guide = card();
        guide.addView(text("사용법 · 3단계", 17, true));
        guide.addView(text(
                "① Secmail에서 답장이 필요한 메일을 직접 엽니다.\n" +
                "② 메일 화면에서 잠깐 기다린 뒤 이 앱으로 돌아와 '현재 메일 읽기'를 누릅니다.\n" +
                "③ 내용이 보이면 'GPT 답변 추천'을 눌러 ChatGPT로 보냅니다.",
                13, false));
        TextView guideNote = text(
                "Inbox 자동수집은 v0.8 Lite에서 사용하지 않습니다. 휴대폰 화면을 계속 켜둘 필요 없이, 사용자가 직접 연 메일 한 통만 처리합니다.",
                11, false);
        guideNote.setTextColor(Color.rgb(37, 99, 235));
        guide.addView(guideNote);
        root.addView(guide);

        LinearLayout mail = card();
        mail.addView(text("2. 현재 열린 메일", 17, true));

        subjectView = text("아직 읽은 메일이 없습니다.", 19, true);
        metaView = text("", 12, false);
        toView = text("", 12, false);
        bodyView = text("", 14, false);
        bodyView.setTextIsSelectable(true);

        mail.addView(subjectView);
        mail.addView(metaView);
        mail.addView(toView);
        mail.addView(divider());
        mail.addView(bodyView);

        Button refresh = button("현재 메일 읽기", true);
        mail.addView(refresh, new LinearLayout.LayoutParams(-1, dp(54)));
        refresh.setOnClickListener(v -> {
            loadMail();
            if (currentMail == null || !currentMail.hasMailContent()) {
                toast("메일이 안 잡히면 Secmail에서 메일을 다시 열고 1초 후 돌아오세요.");
            }
        });

        LinearLayout mailBtns = new LinearLayout(this);
        Button original = button("원문 전체/줄이기", false);
        Button secmailAgain = button("Secmail로 돌아가기", false);
        mailBtns.addView(original, new LinearLayout.LayoutParams(0, dp(48), 1f));
        mailBtns.addView(secmailAgain, new LinearLayout.LayoutParams(0, dp(48), 1f));
        mail.addView(mailBtns);
        original.setOnClickListener(v -> {
            bodyExpanded = !bodyExpanded;
            renderMail();
        });
        secmailAgain.setOnClickListener(v -> openSecmail());

        root.addView(mail);

        LinearLayout gpt = card();
        gpt.addView(text("3. GPT 답변 추천", 17, true));
        TextView gptNote = text(
                "현재 화면에 잡힌 메일 한 통만 ChatGPT 앱으로 보냅니다. " +
                "요약, 상대방 요청, 내가 할 일, 회신 필요 여부와 실제로 보낼 수 있는 추천 답안을 요청합니다.",
                12, false);
        gptNote.setTextColor(Color.rgb(99, 110, 128));
        gpt.addView(gptNote);

        Button askGpt = button("GPT 답변 추천", true);
        gpt.addView(askGpt, new LinearLayout.LayoutParams(-1, dp(58)));
        askGpt.setOnClickListener(v -> shareCurrentMailToGpt());

        TextView privacy = text(
                "회사 정책상 외부 AI 공유가 허용된 메일에만 사용하세요. 첨부파일은 보내지 않으며, 이 버튼을 누른 현재 메일 텍스트만 명시적으로 공유합니다.",
                10, false);
        privacy.setTextColor(Color.rgb(99, 110, 128));
        gpt.addView(privacy);
        root.addView(gpt);

        LinearLayout advanced = card();
        advanced.addView(text("고급 / 문제 확인", 15, true));
        Button debug = button("UI-tree Debug 보기/숨기기", false);
        advanced.addView(debug);

        debugView = text("", 10, false);
        debugView.setTypeface(Typeface.MONOSPACE);
        debugView.setTextIsSelectable(true);
        debugView.setVisibility(View.GONE);
        advanced.addView(debugView);

        debug.setOnClickListener(v -> {
            debugExpanded = !debugExpanded;
            debugView.setVisibility(debugExpanded ? View.VISIBLE : View.GONE);
            if (debugExpanded) {
                debugView.setText(
                        prefs.getString(ProbeAccessibilityService.KEY_CAPTURE, "캡처 없음"));
            }
        });

        TextView debugHelp = text(
                "메일이 안 잡히면 Debug의 첫 줄(detail / subjectChars / bodyChars)을 캡처하면 원인 확인이 쉽습니다.",
                10, false);
        debugHelp.setTextColor(Color.rgb(99, 110, 128));
        advanced.addView(debugHelp);
        root.addView(advanced);

        setContentView(scroll);
        refreshStatus();
        loadMail();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        loadMail();
    }

    private void refreshStatus() {
        serviceStatus.setText(isAccessibilityEnabled()
                ? "● Accessibility ON"
                : "○ Accessibility OFF · 먼저 켜주세요");
        String target = prefs.getString(
                ProbeAccessibilityService.KEY_TARGET,
                ProbeAccessibilityService.DEFAULT_TARGET);
        targetStatus.setText("Target: " + target);
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;

        ComponentName cn = new ComponentName(this, ProbeAccessibilityService.class);
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String s = splitter.next();
            if (s.equalsIgnoreCase(cn.flattenToString())
                    || s.equalsIgnoreCase(cn.flattenToShortString())) {
                return true;
            }
        }
        return false;
    }

    private void openSecmail() {
        String pkg = prefs.getString(
                ProbeAccessibilityService.KEY_TARGET,
                ProbeAccessibilityService.DEFAULT_TARGET).trim();

        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            toast("Secmail 실행 Activity를 찾지 못했습니다. Target: " + pkg);
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void loadMail() {
        MailSnapshot m = new MailSnapshot();
        m.subject = prefs.getString(ProbeAccessibilityService.KEY_SUBJECT, "");
        m.sender = prefs.getString(ProbeAccessibilityService.KEY_SENDER, "");
        m.recipients = prefs.getString(ProbeAccessibilityService.KEY_RECIPIENTS, "");
        m.mailDate = prefs.getString(ProbeAccessibilityService.KEY_MAIL_DATE, "");
        m.body = prefs.getString(ProbeAccessibilityService.KEY_BODY, "");
        m.capturedAt = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE_TIME, "");
        m.packageName = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE_PKG, "");
        currentMail = m;
        renderMail();

        if (debugExpanded) {
            debugView.setText(
                    prefs.getString(ProbeAccessibilityService.KEY_CAPTURE, "캡처 없음"));
        }
    }

    private void renderMail() {
        if (currentMail == null || !currentMail.hasMailContent()) {
            subjectView.setText("아직 읽은 메일이 없습니다.");
            metaView.setText("Secmail에서 메일을 직접 열고 다시 돌아오세요.");
            toView.setText("");
            bodyView.setText("");
            return;
        }

        String subject = cleanSubject(currentMail.subject);
        subjectView.setText(subject.isEmpty() ? "(제목 미확인)" : subject);

        String from = currentMail.sender == null || currentMail.sender.trim().isEmpty()
                ? "—" : currentMail.sender.trim();
        String date = currentMail.mailDate == null || currentMail.mailDate.trim().isEmpty()
                ? "시간 미확인" : currentMail.mailDate.trim();
        metaView.setText("From: " + from + "   ·   " + date);

        String to = currentMail.recipients == null || currentMail.recipients.trim().isEmpty()
                ? "—" : currentMail.recipients.trim();
        toView.setText("To: " + to);

        String body = currentMail.body == null ? "" : currentMail.body;
        if (!bodyExpanded && body.length() > 1600) {
            body = body.substring(0, 1600) + "\n…";
        }
        bodyView.setText(body);
    }

    private void shareCurrentMailToGpt() {
        loadMail();
        if (currentMail == null || !currentMail.hasMailContent()) {
            toast("먼저 Secmail에서 메일을 열고 '현재 메일 읽기'를 눌러주세요.");
            return;
        }

        String prompt = buildCurrentMailPrompt(currentMail);

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Secmail GPT Reply Review");
        send.putExtra(Intent.EXTRA_TEXT, prompt);
        send.setPackage("com.openai.chatgpt");

        try {
            startActivity(send);
        } catch (ActivityNotFoundException e) {
            Intent fallback = new Intent(Intent.ACTION_SEND);
            fallback.setType("text/plain");
            fallback.putExtra(Intent.EXTRA_SUBJECT, "Secmail GPT Reply Review");
            fallback.putExtra(Intent.EXTRA_TEXT, prompt);
            startActivity(Intent.createChooser(fallback, "GPT 분석에 사용할 앱 선택"));
        }
    }

    private String buildCurrentMailPrompt(MailSnapshot m) {
        String body = m.body == null ? "" : m.body.trim();
        if (body.length() > 12000) body = body.substring(0, 12000) + "\n[본문 일부 생략]";

        return "다음 업무 메일을 분석하고 추천 답안을 작성해줘.\n\n" +
                "출력 순서:\n" +
                "1. 한국어 3줄 이내 핵심 요약\n" +
                "2. 상대방의 요청사항\n" +
                "3. 내가 해야 할 Action\n" +
                "4. 회신 필요 여부와 그 이유\n" +
                "5. 바로 보낼 수 있는 추천 답안\n\n" +
                "회신 초안은 원문 언어가 영어면 영어, 중국어면 중국어, 한국어면 한국어로 작성해줘.\n" +
                "Foundry / Fabless / BCD / PMIC / LDMOS / PDK / MPW / NTO / tape-out / wafer / yield / reliability / qualification / ESD / SOA / GDS 등의 반도체 용어 의미를 정확히 유지해줘.\n" +
                "메일에 없는 일정, 가격, 공정 capability, 수율, 고객 commitment, owner, due date, 기술 결과는 만들지 말고 불명확하면 [확인 필요]로 표시해줘.\n" +
                "추천 회신은 실제 업무에 바로 사용할 수 있게 간결하고 전문적으로 작성해줘.\n\n" +
                "[MAIL]\n" +
                "Subject: " + safe(m.subject) + "\n" +
                "From: " + safe(m.sender) + "\n" +
                "To: " + safe(m.recipients) + "\n" +
                "Date: " + safe(m.mailDate) + "\n\n" +
                body;
    }

    private String cleanSubject(String s) {
        String x = safe(s).trim();
        x = x.replaceFirst("(?i)^\\s*(re|fw|fwd)\\s*:\\s*", "");
        return x.trim();
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
