# Secmail Reply Assistant v0.8 Lite

## Product decision

Mobile is no longer an Inbox batch collector.

The primary workflow is now:

`Open one mail in Secmail → return to Secmail Reply Assistant → Current Mail Read → GPT Reply Recommendation → copy the recommended reply → send manually in Secmail`

## Why

The previous Inbox automation required Secmail to stay foreground and depended heavily on the Secmail UI tree. That created poor practical value and high maintenance cost on mobile.

## Active v0.8 Lite features

- Accessibility status check
- Open Secmail
- Capture the currently opened mail
- Show Subject / From / To / Date / Body
- Explicitly share only that mail text to ChatGPT
- Semiconductor-aware prompt
- Recommended reply in the original mail language
- UI-tree Debug for compatibility diagnosis

## Not active in v0.8 Lite UI

- Inbox batch traversal
- bulk collection
- processed-index workflow
- Action Inbox
- batch MAIL_PACK
- GPT JSON import
- automatic Waiting / Done lifecycle

The legacy implementation files remain in source for rollback and future reuse, but the Lite UI does not start them.

## Version

- versionCode: 10
- versionName: 0.8.0
- package: com.mintomax.secmailprobe

## Runtime test

1. Enable Secmail Reply Assistant Accessibility.
2. Open a recent mail in Secmail.
3. Stay on the opened mail for about one second.
4. Return to Secmail Reply Assistant.
5. Tap `현재 메일 읽기`.
6. Verify Subject/Body.
7. Tap `GPT 답변 추천`.
8. Verify ChatGPT opens with only the current mail text and the reply-analysis prompt.
9. Copy the recommended response and send manually in Secmail.

If mail capture still fails, open `UI-tree Debug 보기/숨기기` and capture the first diagnostic lines.
