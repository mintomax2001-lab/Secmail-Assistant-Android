# v0.7.1 Hotfix

Purpose: restore capture of recently opened Secmail messages after possible UI/resource-ID changes.

- Preserves v0.7 known IDs and collector behavior.
- Adds generic header ID-token fallback.
- Adds WebView/content/body/message body fallback.
- Allows body-only detail capture when a real WebView/content body is exposed.
- Adds v0.7.1 capture summary to UI-tree Debug.
- No DB schema, GPT, translation, or auto-send changes.

Runtime check: open recent mail → Assistant → 현재 메일 읽기 → 저장; then test Inbox batch.
